G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.1*
G04 #@! TF.CreationDate,2026-04-27T21:08:29-05:00*
G04 #@! TF.ProjectId,SplitFlapBusBoard,53706c69-7446-46c6-9170-427573426f61,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.1) date 2026-04-27 21:08:29*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.928571X-301.071429X-2.321429X301.071429X-2.321429X301.071429X2.321429X-301.071429X2.321429X0*%
%ADD11RoundRect,0.833333X-302.166667X-0.416667X302.166667X-0.416667X302.166667X0.416667X-302.166667X0.416667X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J2*
X322950000Y-24460000D03*
D11*
X323950000Y-30175000D03*
X323950000Y-33985000D03*
D10*
X322950000Y-39700000D03*
G04 #@! TD*
M02*
